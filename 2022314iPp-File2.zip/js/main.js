$(document).ready(function(){
  $('.bxslider').bxSlider({
  	auto: true,
  });

  /*$(document).ready(function(){
    $(".gallery").owlCarousel();
  });*/

});